@extends("components.layout")

@section("content")
    @component("components.breadcrumbs", ["breadcrumbs" => $breadcrumbs])
    @endcomponent

    <h1>Agregar Reservación</h1>
    
    <form action="{{ url('/movimientos/reservaciones/agregar') }}" method="POST" class="container">
        @csrf
        <br>
        <!--SECCION PARA CHECKBOX-->
        <div class="row">
            <div class="col-md-6">
                <br>
                <input type="checkbox" id="checkVuelo" name="checkVuelo" checked>
                <label for="checkVuelo">Registrar Vuelo</label>
                <br><br>
                <div class="form-group">
                    <label for="vuelo">Vuelo:</label>
                    <select class="form-control" id="vuelo" name="IDVuelo" required>
                        @foreach($vuelos as $vuelo)
                            <option value="{{ $vuelo->IDVuelo }}">{{ $vuelo->destino }}</option>
                        @endforeach
                    </select>
                </div>
                <br>
                <div class="form-group">
                    <label for="claseVuelo">Clase de Vuelo:</label>
                    <select class="form-control" id="claseVuelo" name="IDClaseVuelo" required>
                        @foreach($clasesVuelo as $clase)
                            <option value="{{ $clase->IDClaseVuelo }}">{{ $clase->descripcionClase }}</option>
                        @endforeach
                    </select>
                </div>
                <br>
                <div class="form-group">
                    <label for="fechahoraLlegada">Fecha y Hora de Llegada:</label>
                    <input type="datetime-local" class="form-control" id="fechahoraLlegada" name="fechahoraLlegada">
                </div>
                <br>
                <div class="form-group">
                    <label for="fechahoraSalida">Fecha y Hora de Salida:</label>
                    <input type="datetime-local" class="form-control" id="fechahoraSalida" name="fechahoraSalida">
                </div>
                <br>
            </div>
            <div class="col-md-6">
                <br>
                <input type="checkbox" id="checkHotel" name="checkHotel" checked>
                <label for="checkHotel">Registrar Estadía en Hotel</label>
                <br><br>   
                <div class="form-group">
                    <label for="hotel">Hotel:</label>
                    <select class="form-control" id="hotel" name="IDHotel" required>
                        @foreach($hoteles as $hotel)
                            <option value="{{ $hotel->IDHotel }}">{{ $hotel->nombre }}</option>
                        @endforeach
                    </select>
                </div>
                <br>
                <div class="form-group">
                    <label for="regimenHospedaje">Régimen de Hospedaje:</label>
                    <select class="form-control" id="regimenHospedaje" name="IDRegimenHospedaje" required>
                        @foreach($regimenesHospedaje as $regimen)
                            <option value="{{ $regimen->IDRegimenH }}">{{ $regimen->descripcionRegimen }}</option>
                        @endforeach
                    </select>
                </div>
                <br>
                <div class="form-group">
                    <label for="fechaHoraRegimen">Fecha y Hora de Inicio del Régimen:</label>
                    <input type="datetime-local" class="form-control" id="fechaHoraRegimen" name="fechaHoraRegimen">
                </div>
                <br>
                <div class="form-group">
                    <label for="fechaHoraRegFin">Fecha y Hora de Fin del Régimen:</label>
                    <input type="datetime-local" class="form-control" id="fechaHoraRegFin" name="fechaHoraRegFin">
                </div>
            </div>
        </div>
        <!--SECCION PARA SELECCION DE INF-->
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="cliente">Cliente:</label>
                    <select class="form-control" id="cliente" name="NIFCliente" required>
                        @foreach($clientes as $cliente)
                            <option value="{{ $cliente->NIFCliente }}">{{ $cliente->nombre }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="sucursal">Sucursal:</label>
                    <select class="form-control" id="sucursal" name="IDSucursal" required>
                        @foreach($sucursales as $sucursal)
                            <option value="{{ $sucursal->IDSucursal }}">{{ $sucursal->nombreSucursal }}</option>
                        @endforeach
            </select>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="fechaReservacion">Fecha de Reservación:</label>
                    <input type="datetime-local" class="form-control" id="fechaReservacion" name="fechaReservacion" required>
                </div>
            </div>
        </div>
        <br>
        <!--Catalogar botón para estado y su debido guardar-->
        <div class="row">
            <div class="col-md-4"></div> <!-- Espacio vacío -->
            <div class="col-md-4">
                <div class="form-group">
                    <label for="estado">Estado:</label>
                    <select class="form-control" id="estado" name="estado" required>
                        <option value="1">Activo</option>
                        <option value="0">Inactivo</option>
                    </select>
                </div>
            </div>
            <div class="col-md-4"></div> <!-- Espacio vacío -->
        </div>
        <br><br>
        <div class="row">
            <div class="col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </div>
    </form>
    <script>
    document.getElementById('checkVuelo').addEventListener('change', (event) => {
        var vueloSelects = document.querySelectorAll('#vuelo, #claseVuelo, #fechahoraLlegada, #fechahoraSalida');
        vueloSelects.forEach(function(select) {
            select.required = event.target.checked;
            select.disabled = !event.target.checked;
            if (!event.target.checked) {
                select.value = ''; // Limpiar el valor si el checkbox está desactivado
            }
        });
    });

    document.getElementById('checkHotel').addEventListener('change', (event) => {
        var hotelSelects = document.querySelectorAll('#hotel, #regimenHospedaje, #fechaHoraRegimen, #fechaHoraRegFin');
        hotelSelects.forEach(function(select) {
            select.required = event.target.checked;
            select.disabled = !event.target.checked;
            if (!event.target.checked) {
                select.value = ''; // Limpiar el valor si el checkbox está desactivado
            }
        });
    });
    </script>
@endsection