@extends("components.layout")

@section("content")
    @component("components.breadcrumbs", ["breadcrumbs" => $breadcrumbs])
    @endcomponent

    <h1>Modificar Reservación</h1>
    <form action="{{ route('rhotel.update', ['IDReservacion' => $reservacion->IDReservacion]) }}" method="POST">
        @csrf
        @method('POST')  <!-- Cambia POST a PUT para la actualización -->

        <div class="form-group">
            <label for="IDHotel">Hotel:</label>
            <select class="form-control" id="IDHotel" name="IDHotel" required>
                @foreach($hoteles as $hotel)
                    <option value="{{ $hotel->IDHotel }}" {{ $hotel->IDHotel == $reservacion->IDHotel ? 'selected' : '' }}>
                        {{ $hotel->nombre }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="form-group">
            <label for="IDRegimenHospedaje">Régimen de Hospedaje:</label>
            <select class="form-control" id="IDRegimenHospedaje" name="IDRegimenHospedaje" required>
                @foreach($regimenesHospedaje as $regimen)
                    <option value="{{ $regimen->IDRegimenH }}" {{ $regimen->IDRegimenH == $reservacion->IDRegimenHospedaje ? 'selected' : '' }}>
                        {{ $regimen->descripcionRegimen }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="form-group">
            <label for="estado">Estado:</label>
            <select class="form-control" id="estado" name="estado" required>
                <option value="1" {{ $reservacion->estado == 1 ? 'selected' : '' }}>Activo</option>
                <option value="0" {{ $reservacion->estado == 0 ? 'selected' : '' }}>Inactivo</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
@endsection