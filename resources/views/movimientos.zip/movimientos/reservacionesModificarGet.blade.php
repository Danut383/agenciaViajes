@extends("components.layout")

@section("content")
    @component("components.breadcrumbs", ["breadcrumbs" => $breadcrumbs])
    @endcomponent

    <h1>Modificar Reservación</h1>
    <form action="{{ route('reservaciones.update', ['IDReservacion' => $reservacion->IDReservacion]) }}" method="POST">
        @csrf
        @method('POST')  <!-- Asegúrate de que estás usando POST como método para la actualización -->

        <div class="form-group">
            <label for="sucursal">Sucursal:</label>
            <select class="form-control" id="sucursal" name="IDSucursal" required>
                @foreach($sucursales as $sucursal)
                    <option value="{{ $sucursal->IDSucursal }}" {{ $sucursal->IDSucursal == $reservacion->IDSucursal ? 'selected' : '' }}>
                        {{ $sucursal->nombreSucursal }}
                    </option>
                @endforeach
            </select>
        </div>

        <div class="form-group">
            <label for="fechaReservacion">Fecha de Reservación:</label>
            <input type="datetime-local" class="form-control" id="fechaReservacion" name="fechaReservacion" value="{{ \Carbon\Carbon::parse($reservacion->fechaReservacion)->format('Y-m-d\TH:i') }}" required>
    
        </div>

        <div class="form-group">
            <label for="estado">Estado:</label>
            <select class="form-control" id="estado" name="estado" required>
                <option value="1" {{ $reservacion->estado == 1 ? 'selected' : '' }}>Activo</option>
                <option value="0" {{ $reservacion->estado == 0 ? 'selected' : '' }}>Inactivo</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
@endsection
