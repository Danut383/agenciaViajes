@extends("components.layout")
@section("content")
    @component("components.breadcrumbs", ["breadcrumbs" => $breadcrumbs])
    @endcomponent

    <div class="row my-4">
        <div class="col">
            <h1>Reservaciones</h1>
        </div>
        <div class="col-auto titlebar-commands">
            <a class="btn btn-primary" href="{{ url('movimientos/reservaciones/agregar') }}">Agregar</a>
        </div>
    </div>

    <table class="table" id="maintable">
        <thead>
            <tr>
                <th scope="col">Cliente</th>
                <th scope="col">Sucursal</th>
                <th scope="col">Vuelo</th>
                <th scope="col">Hotel</th>
                <th scope="col">Fecha de Reservación</th>
                <th scope="col">Estado</th>
                <th scope="col">Acciones</th>
            </tr>
        </thead>
        <tbody>
        @foreach ($reservaciones as $reservacion)
            <tr>
                <td>{{ $reservacion->cliente->nombre ?? 'No definido' }}</td>
                <td>{{ $reservacion->sucursal->nombreSucursal ?? 'No definido' }}</td>
                <td>{{ $reservacion->vuelo->destino ?? 'No definido' }}</td>
                <td>{{ $reservacion->hotel ? $reservacion->hotel->nombre : 'No Aplica' }}</td>
                <td class="text-center">{{ \Carbon\Carbon::parse($reservacion->fechaReservacion)->format('Y-m-d H:i:s') }}</td>
                <td class="text-center">{{ $reservacion->estado ? 'Activo' : 'Inactivo' }}</td>
                <td class="text-center">
                    <a href="{{ url("/movimientos/reservaciones/{$reservacion->IDReservacion}/modificar") }}">Modificar</a>
                    <a href="{{ url("/movimientos/reservaciones/{$reservacion->IDReservacion}/modificar_vuelo") }}">Vuelo</a>
                    <a href="{{ url("/movimientos/reservaciones/{$reservacion->IDReservacion}/modificar_hotel") }}">Hotel</a>
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>

    <script>
        new DataTable("#maintable", { paging: true, searching: true });
    </script>
@endsection
