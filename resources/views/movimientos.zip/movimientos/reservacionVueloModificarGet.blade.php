@extends('components.layout')

@section('content')
    @component('components.breadcrumbs', ['breadcrumbs' => $breadcrumbs])
    @endcomponent

    <h1 class="mb-4">Modificar Vuelo</h1>
    <form action="{{ url('movimientos/reservaciones/' . $reservacion->IDReservacion . '/modificar_vuelo') }}" method="POST">
        @csrf
        @method('PUT')  
    
        <div class="row">
            <!-- Columna izquierda -->
            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label for="IDVuelo">Vuelo:</label>
                    <select class="form-control" id="IDVuelo" name="IDVuelo" required>
                        @foreach ($vuelos as $vuelo)
                            <option value="{{ $vuelo->IDVuelo }}" {{ $vuelo->IDVuelo == $reservacion->IDVuelo ? 'selected' : '' }}>{{ $vuelo->origen }} - {{ $vuelo->destino }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group mb-3">
                    <label for="estado">Estado:</label>
                    <select class="form-control" id="estado" name="estado" required>
                        <option value="1" {{ $reservacion->estado == 1 ? 'selected' : '' }}>Activo</option>
                        <option value="0" {{ $reservacion->estado == 0 ? 'selected' : '' }}>Inactivo</option>
                    </select>
                </div>
            </div>
            <!-- Columna Derecha -->
            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label for="IDClaseVuelo">Clase de Vuelo:</label>
                    <select class="form-control" id="IDClaseVuelo" name="IDClaseVuelo" required>
                        @foreach ($clasesVuelo as $clase)
                            <option value="{{ $clase->IDClaseVuelo }}" {{ $clase->IDClaseVuelo == $reservacion->IDClaseVuelo ? 'selected' : '' }}>{{ $clase->descripcionClase }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="row mt-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            </div>
        </div>
    </form>
@endsection
