@extends('components.layout')

@section('content')
    @component('components.breadcrumbs', ['breadcrumbs' => $breadcrumbs])
    @endcomponent

    <h1 class="mb-4">Modificar Hotel</h1>
    <form action="{{ url('/movimientos/reservaciones/' . $reservacion->IDReservacion . '/modificar') }}" method="POST">
        @csrf

        <div class="row">
            <!-- Columna izquierda -->
            <div class="col-md-6">
                <div class="form-group mb-3">
                    <label for="IDSucursal">Sucursal:</label>
                    <select class="form-control" id="IDSucursal" name="IDSucursal" required>
                        @foreach ($sucursales as $sucursal)
                            <option value="{{ $sucursal->IDSucursal }}" {{ $sucursal->IDSucursal == $reservacion->IDSucursal ? 'selected' : '' }}>{{ $sucursal->nombreSucursal }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <!-- Columna izquierda -->
            <div class="col-md-6">
            <div class="form-group mb-3">
                    <label for="estado">Estado:</label>
                    <select class="form-control" id="estado" name="estado" required>
                        <option value="1" {{ $reservacion->estado == 1 ? 'selected' : '' }}>Activo</option>
                        <option value="0" {{ $reservacion->estado == 0 ? 'selected' : '' }}>Inactivo</option>
                    </select>
                </div>
            </div>
            <div class="row mt-4">
            <div class="col text-right">
                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
            </div>
        </div>
    </form>
@endsection